﻿namespace CuaHang.Models.Handler.Email
{
    public class EmailTo
    {
        public string Mail { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
    }
}
