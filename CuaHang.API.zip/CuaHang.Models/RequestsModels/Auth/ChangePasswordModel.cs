﻿
namespace CuaHang.Models.Requests.Auth
{
    public class ChangePasswordModel
    {
       // public Guid id  { get; set; }
        public string NewPassword { get; set; }
    }
}
