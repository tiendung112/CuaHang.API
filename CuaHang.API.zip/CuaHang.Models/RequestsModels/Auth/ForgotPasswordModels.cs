﻿
namespace CuaHang.Models.Requests.Auth
{
    public class ForgotPasswordModel
    {
        public string Email { get; set; }
    }
}
