﻿

namespace CuaHang.Models.Requests.Auth
{
    public class ValidateRegisterModel
    {
        public int MaXacNhan { get; set; }
    }
}
