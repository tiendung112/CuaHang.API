﻿namespace CuaHang.Models.Requests.Auth
{
    public class CreateNewPasswordModel
    {
        public int MaXacNhan { get; set; }
        public  string MatKhau { get; set; }
    }
}
