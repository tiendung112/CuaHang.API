﻿using CuaHang.Models.Requests.Cart_Item;

namespace CuaHang.Models.Requests.Cart
{
    public class Request_ThemCart
    {
        public IEnumerable<Request_ThemCart_Items>? cart_Items { get; set; }
    }
}
