﻿
namespace ThucTapLTSEDU.Repositories.Requests.Orders
{
    public class Request_XacNhanOrder
    {
        public string? MaXacNhan { get; set; }
    }
}
