﻿
namespace CuaHang.Models.Requests.Cart_Item
{
    public class Request_ThemCart_Items
    {
        public int productId { get; set; }
        public int? quantity { get; set; }
    }
}
